package com.example.login_auth_api.infra.security;

import com.example.login_auth_api.domain.user.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.security.oauth2.resource.OAuth2ResourceServerProperties;
import org.springframework.stereotype.Service;

import javax.xml.crypto.AlgorithmMethod;

@Service
public class TokenService {
    @Value("${api.security.token.secret")
    private String secret;

    public String generateToken(User user) {
        try {
    Algorithm algorithm = Algorithm.HMAC256();
        String token = JWT.create().withIssuer("login-auth-api").withSubject()
        } catch (JWTCreationException exception){
            throw new RuntimeException("Erro ao realizar a autenticação")
        }
    }

}