package com.example.login_auth_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginAuthApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
