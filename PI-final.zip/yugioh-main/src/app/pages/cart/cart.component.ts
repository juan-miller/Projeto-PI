import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { CartService } from '../../services/cart.service';
import { Card } from '../../services/card.model';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})

export class CartComponent implements OnInit {
  items: Card[] = [];
  total = 0;
  cartItems: any[] = [];
  constructor(private cartService: CartService) {}

  ngOnInit() {
    this.loadCart();
  }

  loadCart() {
    this.items = this.cartService.getItems();
    this.total = this.cartService.getTotal();
  }

  removeItem(index: number) {
    this.cartService.removeFromCart(index);
    this.loadCart();
  }

  clear() {
    this.cartService.clearCart();
    this.loadCart();
  }
  

checkout() {
  const currentItems = this.cartService.getItems();

  if (currentItems.length === 0) {
    alert('Seu carrinho está vazio!');
    return;
  }

  alert('✅ Compra finalizada com sucesso!');

  this.cartService.clearCart();
  this.loadCart();
}

}