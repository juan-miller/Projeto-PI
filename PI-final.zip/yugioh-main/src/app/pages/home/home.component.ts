import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { CardService } from '../../services/card.service';
import { Card } from '../../services/card.model';
import { CartService } from '../../services/cart.service';




@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  imports: [CommonModule, RouterLink] // necessário para usar routerLink e ngFor
})
export class HomeComponent implements OnInit {
  cards: Card[] = [];

constructor(
  private cardService: CardService,
  private router: Router,
  private cartService: CartService
) {}


  ngOnInit(): void {
    this.loadCards();
  }

  loadCards() {
    this.cardService.getCards().subscribe(data => {
      this.cards = data;
    });
  }

addToCart(card: Card) {
  this.cartService.addToCart(card);
  alert('Card adicionado ao carrinho!');
}


  edit(cardId: number) {
    this.router.navigate(['/cadastro', cardId]);
  }

  delete(id?: number) {
  if (!id) return;
  this.cardService.deleteCard(id).subscribe(() => {
    this.loadCards();
    });
  }
  createCard() {
  this.router.navigate(['/cadastro']);
}

}

