import { Component } from '@angular/core';
import { DefaultLoginLayoutComponent } from '../../components/default-login-layout/default-login-layout.component';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { PrimaryInputComponent } from '../../components/primary-input/primary-input.component';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';
import { ToastrService } from 'ngx-toastr';

interface SignupForm {
  name: FormControl<string>;
  email: FormControl<string>;
  password: FormControl<string>;
  passwordConfirm: FormControl<string>;
  cpf: FormControl<string>;
}

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [
    DefaultLoginLayoutComponent,
    ReactiveFormsModule,
    PrimaryInputComponent
  ],
  providers: [LoginService],
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignUpComponent {
  signupForm: FormGroup<SignupForm>;

  constructor(
    private router: Router,
    private loginService: LoginService,
    private toastService: ToastrService
  ) {
    this.signupForm = new FormGroup<SignupForm>({
      name: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.minLength(3)] }),
      email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email] }),
      password: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.minLength(6)] }),
      passwordConfirm: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.minLength(6)] }),
      cpf: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.minLength(11), Validators.maxLength(14)] })
    });
  }

  submit() {
    if (this.signupForm.invalid) {
      this.toastService.error("Preencha todos os campos corretamente!");
      return;
    }

    const { name, email, password, passwordConfirm, cpf } = this.signupForm.getRawValue();

    if (password !== passwordConfirm) {
      this.toastService.error("As senhas não coincidem!");
      return;
    }

    this.loginService.signup(name, email, password, cpf).subscribe({
      next: () => {
        this.toastService.success("Cadastro realizado com sucesso!");
        this.router.navigate(["login"]);
      },
      error: (err) => {
        console.error(err);
        this.toastService.error("Erro inesperado! Tente novamente mais tarde");
      }
    });
  }

  navigate() {
    this.router.navigate(["login"]);
  }
}
