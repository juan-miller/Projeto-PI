import { Injectable } from '@angular/core';
import { Card } from './card.model';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private items: Card[] = [];

  getItems(): Card[] {
    return this.items;
  }

  addToCart(card: Card) {
    this.items.push(card);
  }

  removeFromCart(index: number) {
    this.items.splice(index, 1);
  }

  clearCart() {
    this.items = [];
  }

  getTotal(): number {
    return this.items.reduce((total, item) => total + item.price, 0);
  }
}
