import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoginResponse } from '../types/login-response.type';
import { tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  apiUrl: string = "http://localhost:8080/auth";

  constructor(private httpClient: HttpClient) { }

  /**
   * Login com email ou CPF
   */
  login(login: string, password: string) {
    return this.httpClient.post<LoginResponse>(`${this.apiUrl}/login`, { login, password }).pipe(
      tap((value) => {
        sessionStorage.setItem("auth-token", value.token);
        sessionStorage.setItem("username", value.name);
      })
    );
  }

  /**
   * Cadastro com nome, email, senha e CPF
   */
  signup(name: string, email: string, password: string, cpf: string) {
    return this.httpClient.post<LoginResponse>(`${this.apiUrl}/register`, { name, email, password, cpf }).pipe(
      tap((value) => {
        sessionStorage.setItem("auth-token", value.token);
        sessionStorage.setItem("username", value.name);
      })
    );
  }
}
