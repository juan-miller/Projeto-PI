package com.example.loginauthapi.dto;

public record RegisterRequestDTO(
        String name,
        String email,
        String cpf,
        String password
) {}
