package com.example.loginauthapi.dto;

public record LoginRequestDTO(
        String login, //email ou CPF
        String password
) {}
