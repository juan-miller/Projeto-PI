package com.example.loginauthapi.controllers;

import com.example.loginauthapi.domain.user.User;
import com.example.loginauthapi.dto.LoginRequestDTO;
import com.example.loginauthapi.dto.RegisterRequestDTO;
import com.example.loginauthapi.dto.ResponseDTO;
import com.example.loginauthapi.infra.security.TokenService;
import com.example.loginauthapi.repositories.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserRepository repository;
    private final PasswordEncoder passwordEncoder;
    private final TokenService tokenService;

    // Valida CPF
    private boolean isValidCpf(String cpf) {
        cpf = cpf.replaceAll("[^0-9]", "");
        if (cpf.length() != 11 || cpf.matches("(\\d)\\1{10}")) return false;
        try {
            int sum1 = 0, sum2 = 0;
            for (int i = 0; i < 9; i++) sum1 += (cpf.charAt(i) - '0') * (10 - i);
            int dv1 = 11 - (sum1 % 11); dv1 = (dv1 >= 10 ? 0 : dv1);
            for (int i = 0; i < 10; i++) sum2 += (cpf.charAt(i) - '0') * (11 - i);
            int dv2 = 11 - (sum2 % 11); dv2 = (dv2 >= 10 ? 0 : dv2);
            return dv1 == (cpf.charAt(9) - '0') && dv2 == (cpf.charAt(10) - '0');
        } catch (Exception e) {
            return false;
        }
    }

    @PostMapping("/login")
    public ResponseEntity login(@RequestBody LoginRequestDTO body) {
        // procura por email ou CPF
        Optional<User> userOpt = repository.findByEmail(body.login());
        if (userOpt.isEmpty()) userOpt = repository.findByCpf(body.login());

        User user = userOpt.orElseThrow(() -> new RuntimeException("User not found"));

        if (passwordEncoder.matches(body.password(), user.getPassword())) {
            String token = tokenService.generateToken(user);
            return ResponseEntity.ok(new ResponseDTO(user.getName(), token));
        }

        return ResponseEntity.badRequest().build();
    }

    @PostMapping("/register")
    public ResponseEntity register(@RequestBody RegisterRequestDTO body) {
        if (!isValidCpf(body.cpf())) {
            return ResponseEntity.badRequest().body("CPF inválido");
        }

        if (repository.findByEmail(body.email()).isPresent() || repository.findByCpf(body.cpf()).isPresent()) {
            return ResponseEntity.badRequest().body("Email ou CPF já cadastrado");
        }

        User newUser = new User();
        newUser.setPassword(passwordEncoder.encode(body.password()));
        newUser.setEmail(body.email());
        newUser.setName(body.name());
        newUser.setCpf(body.cpf()); // adiciona CPF
        repository.save(newUser);

        String token = tokenService.generateToken(newUser);
        return ResponseEntity.ok(new ResponseDTO(newUser.getName(), token));
    }
}
