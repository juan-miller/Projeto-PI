package utils;

public class CpfValidator {

    public static boolean isValid(String cpf) {
        if (cpf == null || cpf.isBlank()) {
            return false; // CPF vazio ou null não é válido
        }

        cpf = cpf.replaceAll("[^0-9]", "");

        // Deve ter 11 dígitos
        if (cpf.length() != 11) return false;

        // Não pode ser sequência igual (ex: 11111111111)
        if (cpf.matches("(\\d)\\1{10}")) return false;

        try {
            int sum1 = 0, sum2 = 0;

            // Primeiro dígito verificador
            for (int i = 0; i < 9; i++) {
                int digit = cpf.charAt(i) - '0';
                sum1 += digit * (10 - i);
            }

            int dv1 = 11 - (sum1 % 11);
            dv1 = (dv1 >= 10) ? 0 : dv1;

            // Segundo dígito verificador
            for (int i = 0; i < 10; i++) {
                int digit = cpf.charAt(i) - '0';
                sum2 += digit * (11 - i);
            }

            int dv2 = 11 - (sum2 % 11);
            dv2 = (dv2 >= 10) ? 0 : dv2;

            // Compara com os dígitos reais
            return dv1 == (cpf.charAt(9) - '0') &&
                    dv2 == (cpf.charAt(10) - '0');

        } catch (Exception e) {
            return false;
        }
    }
}
