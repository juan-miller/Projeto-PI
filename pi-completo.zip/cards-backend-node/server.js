import express from "express";
import cors from "cors";
import fs from "fs";

const app = express();
app.use(cors());
app.use(express.json());

const DATA_FILE = "./cards.json"; // arquivo onde os cards vão ficar gravados

// 🔹 Lê os cards do arquivo JSON
function readCards() {
  if (!fs.existsSync(DATA_FILE)) return [];
  return JSON.parse(fs.readFileSync(DATA_FILE));
}

// 🔹 Salva os cards no arquivo JSON
function saveCards(cards) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(cards, null, 2));
}

// Rota GET → lista todos os cards
app.get("/cards", (req, res) => {
  res.json(readCards());
});

// Rota POST → adiciona um card
app.post("/cards", (req, res) => {
  const cards = readCards();
  const newCard = { id: Date.now(), ...req.body };
  cards.push(newCard);
  saveCards(cards);
  res.status(201).json(newCard);
});

// Rota PUT → edita card
app.put("/cards/:id", (req, res) => {
  const { id } = req.params;
  const cards = readCards();
  const index = cards.findIndex((c) => c.id == id);

  if (index === -1) return res.status(404).json({ message: "Card não encontrado" });

  cards[index] = { ...cards[index], ...req.body };
  saveCards(cards);
  res.json(cards[index]);
});

// Rota DELETE → apaga card
app.delete("/cards/:id", (req, res) => {
  const { id } = req.params;
  const cards = readCards();
  const filtered = cards.filter((c) => c.id != id);
  saveCards(filtered);
  res.json({ message: "Card removido com sucesso" });
});

// Porta do backend
app.listen(3000, () => console.log("✅ Backend de cards rodando em http://localhost:3000"));
