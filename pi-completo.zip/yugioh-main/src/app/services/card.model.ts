export interface Card {
  id?: number;        
  name: string;
  imageUrl: string;
  price: number;
}
