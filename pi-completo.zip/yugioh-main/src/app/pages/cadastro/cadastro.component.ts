import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { Card } from '../../services/card.model';
import { CardService } from '../../services/card.service';

@Component({
  selector: 'app-cadastro',
  standalone: true,
  templateUrl: './cadastro.component.html',
  styleUrls: ['./cadastro.component.scss'],
  imports: [FormsModule, CommonModule]
})
export class CadastroComponent implements OnInit {

  card: Card = {
    name: '',
    price: 0,
    imageUrl: ''
  };

  editing = false;

  constructor(
    private cardService: CardService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');

    if (idParam) {
      this.editing = true;
      const id = Number(idParam);

      this.cardService.getCard(id).subscribe(data => {
        this.card = data;
      });
    }
  }

  save() {
    if (this.editing && this.card.id) {
      this.cardService.updateCard(this.card.id, this.card).subscribe(() => {
        alert("Card atualizado com sucesso!");
        this.router.navigate(['/home']);
      });
    } else {
      this.cardService.createCard(this.card).subscribe(() => {
        alert("Card criado com sucesso!");
        this.router.navigate(['/home']);
      });
    }
  }
}
