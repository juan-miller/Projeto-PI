import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { SignUpComponent } from './pages/signup/signup.component';
import { HomeComponent } from './pages/home/home.component';
import { CadastroComponent } from './pages/cadastro/cadastro.component'; // ✅ novo import
import { AuthGuard } from './services/auth-guard.service';

export const routes: Routes = [
    {
        path: "login",
        component: LoginComponent
    },
    {
        path: "signup",
        component: SignUpComponent
    },
    {
        path: "home",
        component: HomeComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "cadastro",              // ✅ tela para criar novo card
        component: CadastroComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "cadastro/:id",          // ✅ tela para editar card existente
        component: CadastroComponent,
        canActivate: [AuthGuard]
    },
    {
        path: "",
        redirectTo: "login",
        pathMatch: "full"
    }
];
